<?php
return array (
    'name' => 'RamCMS',
    'copyright' => 'RamCMS',
    'url' => '//github.com/brevis-ng/ramcms',
    'code' => '2023.1000.3052.1',
    'license' => 'MIT',
);
?>